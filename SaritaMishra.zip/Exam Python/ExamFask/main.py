from flask import Flask, render_template
from flask_restful import Resource, Api
app = Flask(__name__) 
api = Api(app)  

class HelloWorld(Resource):
    def get(self):
        return {'Hello': 'World'}

api.add_resource(HelloWorld, '/apiEngine')

@app.route('/')
def home():
    return render_template("Home.html")
